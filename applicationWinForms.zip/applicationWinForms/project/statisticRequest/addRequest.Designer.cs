﻿using System.Drawing;
using System.Windows.Forms;

namespace statisticRequest
{
    partial class addRequest
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addRequest));
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.maskedTextBoxDate = new System.Windows.Forms.MaskedTextBox();
            this.labelClient = new System.Windows.Forms.Label();
            this.comboBoxClient = new System.Windows.Forms.ComboBox();
            this.labelEquipment = new System.Windows.Forms.Label();
            this.comboBoxEquipment = new System.Windows.Forms.ComboBox();
            this.labelType = new System.Windows.Forms.Label();
            this.comboBoxType = new System.Windows.Forms.ComboBox();
            this.labelDescription = new System.Windows.Forms.Label();
            this.richTextBoxDescription = new System.Windows.Forms.RichTextBox();
            this.labelStatus = new System.Windows.Forms.Label();
            this.comboBoxStatus = new System.Windows.Forms.ComboBox();
            this.labelSpecialist = new System.Windows.Forms.Label();
            this.comboBoxSpecialist = new System.Windows.Forms.ComboBox();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox
            // 
            this.groupBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.groupBox.Controls.Add(this.labelDate);
            this.groupBox.Controls.Add(this.maskedTextBoxDate);
            this.groupBox.Controls.Add(this.labelClient);
            this.groupBox.Controls.Add(this.comboBoxClient);
            this.groupBox.Controls.Add(this.labelEquipment);
            this.groupBox.Controls.Add(this.comboBoxEquipment);
            this.groupBox.Controls.Add(this.labelType);
            this.groupBox.Controls.Add(this.comboBoxType);
            this.groupBox.Controls.Add(this.labelDescription);
            this.groupBox.Controls.Add(this.richTextBoxDescription);
            this.groupBox.Controls.Add(this.labelStatus);
            this.groupBox.Controls.Add(this.comboBoxStatus);
            this.groupBox.Controls.Add(this.labelSpecialist);
            this.groupBox.Controls.Add(this.comboBoxSpecialist);
            this.groupBox.Controls.Add(this.buttonAdd);
            this.groupBox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.groupBox.ForeColor = System.Drawing.Color.Black;
            this.groupBox.Location = new System.Drawing.Point(20, 20);
            this.groupBox.Name = "groupBox";
            this.groupBox.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox.Size = new System.Drawing.Size(560, 400);
            this.groupBox.TabIndex = 0;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "Добавление заявки";
            // 
            // labelDate
            // 
            this.labelDate.Location = new System.Drawing.Point(20, 30);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(150, 25);
            this.labelDate.TabIndex = 0;
            this.labelDate.Text = "Дата:";
            // 
            // maskedTextBoxDate
            // 
            this.maskedTextBoxDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.maskedTextBoxDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.maskedTextBoxDate.ForeColor = System.Drawing.Color.White;
            this.maskedTextBoxDate.Location = new System.Drawing.Point(180, 30);
            this.maskedTextBoxDate.Mask = "00.00.0000";
            this.maskedTextBoxDate.Name = "maskedTextBoxDate";
            this.maskedTextBoxDate.Size = new System.Drawing.Size(100, 30);
            this.maskedTextBoxDate.TabIndex = 1;
            // 
            // labelClient
            // 
            this.labelClient.Location = new System.Drawing.Point(20, 70);
            this.labelClient.Name = "labelClient";
            this.labelClient.Size = new System.Drawing.Size(150, 25);
            this.labelClient.TabIndex = 2;
            this.labelClient.Text = "Клиент:";
            // 
            // comboBoxClient
            // 
            this.comboBoxClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.comboBoxClient.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxClient.ForeColor = System.Drawing.Color.White;
            this.comboBoxClient.Location = new System.Drawing.Point(180, 70);
            this.comboBoxClient.Name = "comboBoxClient";
            this.comboBoxClient.Size = new System.Drawing.Size(340, 31);
            this.comboBoxClient.TabIndex = 3;
            // 
            // labelEquipment
            // 
            this.labelEquipment.Location = new System.Drawing.Point(20, 110);
            this.labelEquipment.Name = "labelEquipment";
            this.labelEquipment.Size = new System.Drawing.Size(150, 25);
            this.labelEquipment.TabIndex = 4;
            this.labelEquipment.Text = "Оборудование:";
            // 
            // comboBoxEquipment
            // 
            this.comboBoxEquipment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.comboBoxEquipment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEquipment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxEquipment.ForeColor = System.Drawing.Color.White;
            this.comboBoxEquipment.Location = new System.Drawing.Point(180, 110);
            this.comboBoxEquipment.Name = "comboBoxEquipment";
            this.comboBoxEquipment.Size = new System.Drawing.Size(340, 31);
            this.comboBoxEquipment.TabIndex = 5;
            // 
            // labelType
            // 
            this.labelType.Location = new System.Drawing.Point(20, 150);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(150, 25);
            this.labelType.TabIndex = 6;
            this.labelType.Text = "Тип ремонта:";
            // 
            // comboBoxType
            // 
            this.comboBoxType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.comboBoxType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxType.ForeColor = System.Drawing.Color.White;
            this.comboBoxType.Location = new System.Drawing.Point(180, 150);
            this.comboBoxType.Name = "comboBoxType";
            this.comboBoxType.Size = new System.Drawing.Size(340, 31);
            this.comboBoxType.TabIndex = 7;
            // 
            // labelDescription
            // 
            this.labelDescription.Location = new System.Drawing.Point(20, 190);
            this.labelDescription.Name = "labelDescription";
            this.labelDescription.Size = new System.Drawing.Size(150, 25);
            this.labelDescription.TabIndex = 8;
            this.labelDescription.Text = "Описание:";
            // 
            // richTextBoxDescription
            // 
            this.richTextBoxDescription.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.richTextBoxDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBoxDescription.ForeColor = System.Drawing.Color.White;
            this.richTextBoxDescription.Location = new System.Drawing.Point(180, 190);
            this.richTextBoxDescription.Name = "richTextBoxDescription";
            this.richTextBoxDescription.Size = new System.Drawing.Size(340, 60);
            this.richTextBoxDescription.TabIndex = 9;
            this.richTextBoxDescription.Text = "";
            // 
            // labelStatus
            // 
            this.labelStatus.Location = new System.Drawing.Point(20, 260);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(150, 25);
            this.labelStatus.TabIndex = 10;
            this.labelStatus.Text = "Статус:";
            // 
            // comboBoxStatus
            // 
            this.comboBoxStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.comboBoxStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxStatus.ForeColor = System.Drawing.Color.White;
            this.comboBoxStatus.Location = new System.Drawing.Point(180, 260);
            this.comboBoxStatus.Name = "comboBoxStatus";
            this.comboBoxStatus.Size = new System.Drawing.Size(340, 31);
            this.comboBoxStatus.TabIndex = 11;
            // 
            // labelSpecialist
            // 
            this.labelSpecialist.Location = new System.Drawing.Point(20, 300);
            this.labelSpecialist.Name = "labelSpecialist";
            this.labelSpecialist.Size = new System.Drawing.Size(150, 25);
            this.labelSpecialist.TabIndex = 12;
            this.labelSpecialist.Text = "Специалист:";
            // 
            // comboBoxSpecialist
            // 
            this.comboBoxSpecialist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.comboBoxSpecialist.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpecialist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxSpecialist.ForeColor = System.Drawing.Color.White;
            this.comboBoxSpecialist.Location = new System.Drawing.Point(180, 300);
            this.comboBoxSpecialist.Name = "comboBoxSpecialist";
            this.comboBoxSpecialist.Size = new System.Drawing.Size(340, 31);
            this.comboBoxSpecialist.TabIndex = 13;
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonAdd.FlatAppearance.BorderSize = 0;
            this.buttonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAdd.ForeColor = System.Drawing.Color.Black;
            this.buttonAdd.Location = new System.Drawing.Point(180, 350);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(120, 35);
            this.buttonAdd.TabIndex = 14;
            this.buttonAdd.Text = "Добавить";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // addRequest
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(598, 431);
            this.Controls.Add(this.groupBox);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(616, 478);
            this.MinimumSize = new System.Drawing.Size(616, 478);
            this.Name = "addRequest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Добавление заявки";
            this.Load += new System.EventHandler(this.addRequest_Load);
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label labelClient;
        private System.Windows.Forms.Label labelEquipment;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelDescription;
        private System.Windows.Forms.Label labelStatus;
        private System.Windows.Forms.Label labelSpecialist;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxDate;
        private System.Windows.Forms.ComboBox comboBoxClient;
        private System.Windows.Forms.ComboBox comboBoxEquipment;
        private System.Windows.Forms.ComboBox comboBoxType;
        private System.Windows.Forms.ComboBox comboBoxStatus;
        private System.Windows.Forms.ComboBox comboBoxSpecialist;
        private System.Windows.Forms.RichTextBox richTextBoxDescription;
    }
}

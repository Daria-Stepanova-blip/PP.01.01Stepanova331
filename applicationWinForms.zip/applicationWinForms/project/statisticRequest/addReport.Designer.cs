﻿using System.Drawing;
using System.Windows.Forms;

namespace statisticRequest
{
    partial class addReport
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addReport));
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.labelRequest = new System.Windows.Forms.Label();
            this.comboBoxRequest = new System.Windows.Forms.ComboBox();
            this.labelSpecialist = new System.Windows.Forms.Label();
            this.comboBoxSpecialist = new System.Windows.Forms.ComboBox();
            this.labelDescription = new System.Windows.Forms.Label();
            this.richTextBoxDescription = new System.Windows.Forms.RichTextBox();
            this.labelTime = new System.Windows.Forms.Label();
            this.textBoxTime = new System.Windows.Forms.TextBox();
            this.labelMaterial = new System.Windows.Forms.Label();
            this.textBoxMaterial = new System.Windows.Forms.TextBox();
            this.labelTotal = new System.Windows.Forms.Label();
            this.textBoxTotal = new System.Windows.Forms.TextBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.maskedTextBoxDate = new System.Windows.Forms.MaskedTextBox();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox
            // 
            this.groupBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.groupBox.Controls.Add(this.labelRequest);
            this.groupBox.Controls.Add(this.comboBoxRequest);
            this.groupBox.Controls.Add(this.labelSpecialist);
            this.groupBox.Controls.Add(this.comboBoxSpecialist);
            this.groupBox.Controls.Add(this.labelDescription);
            this.groupBox.Controls.Add(this.richTextBoxDescription);
            this.groupBox.Controls.Add(this.labelTime);
            this.groupBox.Controls.Add(this.textBoxTime);
            this.groupBox.Controls.Add(this.labelMaterial);
            this.groupBox.Controls.Add(this.textBoxMaterial);
            this.groupBox.Controls.Add(this.labelTotal);
            this.groupBox.Controls.Add(this.textBoxTotal);
            this.groupBox.Controls.Add(this.labelDate);
            this.groupBox.Controls.Add(this.maskedTextBoxDate);
            this.groupBox.Controls.Add(this.buttonAdd);
            this.groupBox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.groupBox.ForeColor = System.Drawing.Color.Black;
            this.groupBox.Location = new System.Drawing.Point(20, 20);
            this.groupBox.Name = "groupBox";
            this.groupBox.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox.Size = new System.Drawing.Size(500, 405);
            this.groupBox.TabIndex = 0;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "Добавление отчета";
            // 
            // labelRequest
            // 
            this.labelRequest.Location = new System.Drawing.Point(20, 30);
            this.labelRequest.Name = "labelRequest";
            this.labelRequest.Size = new System.Drawing.Size(171, 25);
            this.labelRequest.TabIndex = 0;
            this.labelRequest.Text = "Заявка:";
            // 
            // comboBoxRequest
            // 
            this.comboBoxRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.comboBoxRequest.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxRequest.ForeColor = System.Drawing.Color.White;
            this.comboBoxRequest.Location = new System.Drawing.Point(197, 30);
            this.comboBoxRequest.Name = "comboBoxRequest";
            this.comboBoxRequest.Size = new System.Drawing.Size(273, 31);
            this.comboBoxRequest.TabIndex = 1;
            // 
            // labelSpecialist
            // 
            this.labelSpecialist.Location = new System.Drawing.Point(20, 70);
            this.labelSpecialist.Name = "labelSpecialist";
            this.labelSpecialist.Size = new System.Drawing.Size(171, 25);
            this.labelSpecialist.TabIndex = 2;
            this.labelSpecialist.Text = "Специалист:";
            // 
            // comboBoxSpecialist
            // 
            this.comboBoxSpecialist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.comboBoxSpecialist.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpecialist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxSpecialist.ForeColor = System.Drawing.Color.White;
            this.comboBoxSpecialist.Location = new System.Drawing.Point(197, 70);
            this.comboBoxSpecialist.Name = "comboBoxSpecialist";
            this.comboBoxSpecialist.Size = new System.Drawing.Size(273, 31);
            this.comboBoxSpecialist.TabIndex = 3;
            // 
            // labelDescription
            // 
            this.labelDescription.Location = new System.Drawing.Point(20, 110);
            this.labelDescription.Name = "labelDescription";
            this.labelDescription.Size = new System.Drawing.Size(171, 25);
            this.labelDescription.TabIndex = 4;
            this.labelDescription.Text = "Описание:";
            // 
            // richTextBoxDescription
            // 
            this.richTextBoxDescription.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.richTextBoxDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBoxDescription.ForeColor = System.Drawing.Color.White;
            this.richTextBoxDescription.Location = new System.Drawing.Point(197, 110);
            this.richTextBoxDescription.Name = "richTextBoxDescription";
            this.richTextBoxDescription.Size = new System.Drawing.Size(273, 60);
            this.richTextBoxDescription.TabIndex = 5;
            this.richTextBoxDescription.Text = "";
            // 
            // labelTime
            // 
            this.labelTime.Location = new System.Drawing.Point(20, 180);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(171, 25);
            this.labelTime.TabIndex = 6;
            this.labelTime.Text = "Время (часы):";
            // 
            // textBoxTime
            // 
            this.textBoxTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBoxTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTime.ForeColor = System.Drawing.Color.White;
            this.textBoxTime.Location = new System.Drawing.Point(197, 180);
            this.textBoxTime.Name = "textBoxTime";
            this.textBoxTime.Size = new System.Drawing.Size(273, 30);
            this.textBoxTime.TabIndex = 7;
            // 
            // labelMaterial
            // 
            this.labelMaterial.Location = new System.Drawing.Point(19, 220);
            this.labelMaterial.Name = "labelMaterial";
            this.labelMaterial.Size = new System.Drawing.Size(167, 25);
            this.labelMaterial.TabIndex = 8;
            this.labelMaterial.Text = "Стоимость запчастей:";
            // 
            // textBoxMaterial
            // 
            this.textBoxMaterial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBoxMaterial.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxMaterial.ForeColor = System.Drawing.Color.White;
            this.textBoxMaterial.Location = new System.Drawing.Point(197, 220);
            this.textBoxMaterial.Name = "textBoxMaterial";
            this.textBoxMaterial.Size = new System.Drawing.Size(273, 30);
            this.textBoxMaterial.TabIndex = 9;
            // 
            // labelTotal
            // 
            this.labelTotal.Location = new System.Drawing.Point(20, 260);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(171, 25);
            this.labelTotal.TabIndex = 10;
            this.labelTotal.Text = "Стоимость:";
            // 
            // textBoxTotal
            // 
            this.textBoxTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBoxTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTotal.ForeColor = System.Drawing.Color.White;
            this.textBoxTotal.Location = new System.Drawing.Point(197, 260);
            this.textBoxTotal.Name = "textBoxTotal";
            this.textBoxTotal.Size = new System.Drawing.Size(273, 30);
            this.textBoxTotal.TabIndex = 11;
            // 
            // labelDate
            // 
            this.labelDate.Location = new System.Drawing.Point(20, 300);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(166, 25);
            this.labelDate.TabIndex = 12;
            this.labelDate.Text = "Дата:";
            // 
            // maskedTextBoxDate
            // 
            this.maskedTextBoxDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.maskedTextBoxDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.maskedTextBoxDate.ForeColor = System.Drawing.Color.White;
            this.maskedTextBoxDate.Location = new System.Drawing.Point(197, 300);
            this.maskedTextBoxDate.Mask = "00.00.0000";
            this.maskedTextBoxDate.Name = "maskedTextBoxDate";
            this.maskedTextBoxDate.Size = new System.Drawing.Size(120, 30);
            this.maskedTextBoxDate.TabIndex = 13;
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonAdd.FlatAppearance.BorderSize = 0;
            this.buttonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAdd.ForeColor = System.Drawing.Color.Black;
            this.buttonAdd.Location = new System.Drawing.Point(197, 347);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(120, 35);
            this.buttonAdd.TabIndex = 14;
            this.buttonAdd.Text = "Добавить";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // addReport
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(538, 432);
            this.Controls.Add(this.groupBox);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ForeColor = System.Drawing.Color.Transparent;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(556, 479);
            this.MinimumSize = new System.Drawing.Size(556, 479);
            this.Name = "addReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Добавление отчета";
            this.Load += new System.EventHandler(this.addReport_Load);
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.Label labelRequest;
        private System.Windows.Forms.ComboBox comboBoxRequest;
        private System.Windows.Forms.Label labelSpecialist;
        private System.Windows.Forms.ComboBox comboBoxSpecialist;
        private System.Windows.Forms.Label labelDescription;
        private System.Windows.Forms.RichTextBox richTextBoxDescription;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.TextBox textBoxTime;
        private System.Windows.Forms.Label labelMaterial;
        private System.Windows.Forms.TextBox textBoxMaterial;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.TextBox textBoxTotal;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxDate;
        private System.Windows.Forms.Button buttonAdd;
    }
}

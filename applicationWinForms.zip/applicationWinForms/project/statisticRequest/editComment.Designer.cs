﻿namespace statisticRequest
{
    partial class editComment
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(editComment));
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.labelRequest = new System.Windows.Forms.Label();
            this.comboBoxRequest = new System.Windows.Forms.ComboBox();
            this.labelSpecialist = new System.Windows.Forms.Label();
            this.comboBoxSpecialist = new System.Windows.Forms.ComboBox();
            this.labelComment = new System.Windows.Forms.Label();
            this.richTextBoxComment = new System.Windows.Forms.RichTextBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.maskedTextBoxDate = new System.Windows.Forms.MaskedTextBox();
            this.buttonEdit = new System.Windows.Forms.Button();
            this.groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox
            // 
            this.groupBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.groupBox.Controls.Add(this.labelRequest);
            this.groupBox.Controls.Add(this.comboBoxRequest);
            this.groupBox.Controls.Add(this.labelSpecialist);
            this.groupBox.Controls.Add(this.comboBoxSpecialist);
            this.groupBox.Controls.Add(this.labelComment);
            this.groupBox.Controls.Add(this.richTextBoxComment);
            this.groupBox.Controls.Add(this.labelDate);
            this.groupBox.Controls.Add(this.maskedTextBoxDate);
            this.groupBox.Controls.Add(this.buttonEdit);
            this.groupBox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.groupBox.ForeColor = System.Drawing.Color.Black;
            this.groupBox.Location = new System.Drawing.Point(20, 20);
            this.groupBox.Name = "groupBox";
            this.groupBox.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox.Size = new System.Drawing.Size(460, 310);
            this.groupBox.TabIndex = 0;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "Редактирование комментария";
            // 
            // labelRequest
            // 
            this.labelRequest.Location = new System.Drawing.Point(20, 30);
            this.labelRequest.Name = "labelRequest";
            this.labelRequest.Size = new System.Drawing.Size(150, 25);
            this.labelRequest.TabIndex = 0;
            this.labelRequest.Text = "Заявка:";
            // 
            // comboBoxRequest
            // 
            this.comboBoxRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.comboBoxRequest.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxRequest.ForeColor = System.Drawing.Color.White;
            this.comboBoxRequest.Location = new System.Drawing.Point(180, 30);
            this.comboBoxRequest.Name = "comboBoxRequest";
            this.comboBoxRequest.Size = new System.Drawing.Size(250, 31);
            this.comboBoxRequest.TabIndex = 1;
            // 
            // labelSpecialist
            // 
            this.labelSpecialist.Location = new System.Drawing.Point(20, 70);
            this.labelSpecialist.Name = "labelSpecialist";
            this.labelSpecialist.Size = new System.Drawing.Size(150, 25);
            this.labelSpecialist.TabIndex = 2;
            this.labelSpecialist.Text = "Специалист:";
            // 
            // comboBoxSpecialist
            // 
            this.comboBoxSpecialist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.comboBoxSpecialist.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpecialist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxSpecialist.ForeColor = System.Drawing.Color.White;
            this.comboBoxSpecialist.Location = new System.Drawing.Point(180, 70);
            this.comboBoxSpecialist.Name = "comboBoxSpecialist";
            this.comboBoxSpecialist.Size = new System.Drawing.Size(250, 31);
            this.comboBoxSpecialist.TabIndex = 3;
            // 
            // labelComment
            // 
            this.labelComment.Location = new System.Drawing.Point(20, 110);
            this.labelComment.Name = "labelComment";
            this.labelComment.Size = new System.Drawing.Size(150, 25);
            this.labelComment.TabIndex = 4;
            this.labelComment.Text = "Комментарий:";
            // 
            // richTextBoxComment
            // 
            this.richTextBoxComment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.richTextBoxComment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBoxComment.ForeColor = System.Drawing.Color.White;
            this.richTextBoxComment.Location = new System.Drawing.Point(180, 110);
            this.richTextBoxComment.Name = "richTextBoxComment";
            this.richTextBoxComment.Size = new System.Drawing.Size(250, 60);
            this.richTextBoxComment.TabIndex = 5;
            this.richTextBoxComment.Text = "";
            // 
            // labelDate
            // 
            this.labelDate.Location = new System.Drawing.Point(20, 180);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(150, 25);
            this.labelDate.TabIndex = 6;
            this.labelDate.Text = "Дата:";
            // 
            // maskedTextBoxDate
            // 
            this.maskedTextBoxDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.maskedTextBoxDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.maskedTextBoxDate.ForeColor = System.Drawing.Color.White;
            this.maskedTextBoxDate.Location = new System.Drawing.Point(180, 180);
            this.maskedTextBoxDate.Mask = "00.00.0000";
            this.maskedTextBoxDate.Name = "maskedTextBoxDate";
            this.maskedTextBoxDate.Size = new System.Drawing.Size(100, 30);
            this.maskedTextBoxDate.TabIndex = 7;
            // 
            // buttonEdit
            // 
            this.buttonEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonEdit.FlatAppearance.BorderSize = 0;
            this.buttonEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEdit.ForeColor = System.Drawing.Color.Black;
            this.buttonEdit.Location = new System.Drawing.Point(180, 230);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(120, 35);
            this.buttonEdit.TabIndex = 8;
            this.buttonEdit.Text = "Изменить";
            this.buttonEdit.UseVisualStyleBackColor = false;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // editComment
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(498, 346);
            this.Controls.Add(this.groupBox);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(516, 393);
            this.MinimumSize = new System.Drawing.Size(516, 393);
            this.Name = "editComment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Редактирование комментария";
            this.Load += new System.EventHandler(this.editComment_Load);
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.Label labelRequest;
        private System.Windows.Forms.ComboBox comboBoxRequest;
        private System.Windows.Forms.Label labelSpecialist;
        private System.Windows.Forms.ComboBox comboBoxSpecialist;
        private System.Windows.Forms.Label labelComment;
        private System.Windows.Forms.RichTextBox richTextBoxComment;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxDate;
        private System.Windows.Forms.Button buttonEdit;
    }
}
